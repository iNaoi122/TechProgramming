var searchData=
[
  ['operator_3d_0',['operator=',['../class_data_base.html#a5e9f76913cd3fac2e6334430a7199e7e',1,'DataBase']]]
];
