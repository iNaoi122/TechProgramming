var searchData=
[
  ['serverlogic_0',['ServerLogic',['../class_server_logic.html',1,'']]]
];
