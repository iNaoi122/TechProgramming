var searchData=
[
  ['reg_0',['reg',['../class_data_base.html#abffbee8be21b1375e6dc0e56ea2e8d31',1,'DataBase']]],
  ['requestanalyzer_1',['requestAnalyzer',['../class_server_logic.html#a9119683c1354b502abb1da696e258c9d',1,'ServerLogic']]]
];
